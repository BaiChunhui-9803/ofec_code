#include "GL_cont.h"
#include "adaptor_cont.h"
#include <list>
#include "../../../../core/problem/continuous/continuous.h"

#include <iomanip>

#ifdef OFEC_DEMON
#include "../../../../../ui/buffer/scene.h"
extern unique_ptr<scene> msp_buffer;
extern bool ofg_algTermination;
#endif
namespace OFEC {
	GL_cont::GL_cont(param_map &v) :GL<population<individual<>>>(v)/*, m_tree(nullptr)*/ {
		m_adaptor.reset(new EDA::adaptor_cont<individual<>>(global::ms_global->m_problem->variable_size(), this->size()));
		if (v.find("alpha") != v.end())
			m_alpha = v["alpha"];
		else
			m_alpha = -1;
		//buildtree();
		//m_numActive = this->size();
		if (CONTINOUS_CAST->has_tag(problem_tag::GOP))
			CONTINOUS_CAST->set_eval_monitor_flag(true);
	}

	void GL_cont::initialize_curpop() {
		for (int i = 0; i < this->size(); i++) {
			m_curPop.push_back(*m_pop[i]);
		}
	}

	//void GL_cont::buildtree() {
	//	int numDim = global::ms_global->m_problem->variable_size();
	//	std::vector<std::pair<real, real>> box(numDim);
	//	for (int i = 0; i < numDim; ++i) {
	//		box[i] = CONTINOUS_CAST->range(i);
	//	}
	//	std::vector<real> ratio(size(), 1. / size());
	//	m_tree.reset(new KDTreeSpace::PartitioningKDTree<real>(numDim, ratio, box));
	//	m_tree->buildIndex();
	//}

	//bool GL_cont::removeConverged() {
	//	std::map<int, std::list<int>> group;
	//	for (int i = 0; i < this->size(); i++) {
	//		int idx = m_tree->get_regionIdx(m_pop[i]->variable().vect());
	//		auto j = group[idx].begin();
	//		while (j != group[idx].end()) {
	//			if (m_pop[*j]->dominate(*m_pop[i])) ++j;
	//			else break;
	//		}
	//		group[idx].insert(j, i);
	//	}
	//	int actgroup = 0, actind = 0;
	//	real ratio = 0;
	//	for (auto &i : group) {
	//		if (i.second.size() > 1 && global::ms_arg.find("epsilon") != global::ms_arg.end()) {
	//			real d = 0, vol = m_tree->getBoxVolume(i.first);
	//			for (auto j = ++i.second.begin(); j != i.second.end(); ++j) {
	//				//d += m_pop[i.second.front()]->getDistance(m_pop[*j]->data());
	//				d += m_pop[i.second.front()]->objective_distance(*m_pop[*j]);
	//			}
	//			d /= i.second.size();
	//			ratio += d / vol;
	//			if (global::ms_arg["epsilon"] > d) {// converged at region idx
	//				for (auto j : i.second) {
	//					m_pop[j]->set_active_flag(false);
	//				}
	//			}
	//			else {
	//				for (auto j : i.second) 				m_pop[j]->set_active_flag(true);
	//				actgroup++;
	//				actind += i.second.size();
	//			}
	//		}
	//		else {
	//			actgroup++;
	//			actind += i.second.size();
	//		}
	//	}
	//	m_numActive = 0;
	//	for (int i = 0; i < this->size(); i++) if (m_pop[i]->is_active()) m_numActive++;
	//	//cout << group.size() << " "<<actgroup<<" "<< actind<<" "<< ratio<<" ";
	//	return false;
	//}

	void GL_cont::initialize() {
		population<individual<>>::initialize();
		initialize_memory();
		initialize_curpop();
	}

	evaluation_tag GL_cont::evolve() {
#ifdef OFEC_DEMON
		std::vector<const algorithm*> vp;
		vp.push_back(this);
		msp_buffer->updateBuffer_(&vp);
#endif

		dynamic_cast<EDA::adaptor_cont<individual<>>*>(m_adaptor.get())->update_step(m_pop);

		if (m_ms != UpdateScheme::hb) {
			m_adaptor->create_solution(m_pop, m_curPop, m_alpha);
		}
		else {
			m_adaptor->create_solution(m_pop, m_curPop, m_hisIndi, m_alpha);
		}

		evaluation_tag rf = update();

		for (auto &i : m_pop)
			if (i->is_improved())
				update_best(*i);

		//if (global::ms_global->m_problem->has_tag(problem_tag::MMOP))
		//	removeConverged();

		// dynamic_cast<adaptor_cont<individual<>>*>(m_adaptor.get())->repel(m_pop);

		update_memory();
		m_iter++;

#ifdef OFEC_DEMON	
		if (CONTINOUS_CAST->has_tag(problem_tag::MMOP))
			std::cout << m_iter << "\t" << CONTINOUS_CAST->get_optima().num_objective_found() << std::endl;
		else if (CONTINOUS_CAST->has_tag(problem_tag::GOP)) {
			size_t evals = CONTINOUS_CAST->evaluations();
			real err = std::fabs(problem::get_sofar_best<solution<>>(0)->objective(0) - CONTINOUS_CAST->get_optima().objective(0).at(0));
			std::cout << "eval:" << evals << "\t" << "err:" << err << std::endl;
		}
#endif

		return rf;
	}

	void GL_cont::record() {
		if (global::ms_global->m_problem->has_tag(problem_tag::MMOP)) {
			// ******* Multi-Modal Optimization *******
			size_t evals = CONTINOUS_CAST->total_evaluations();
			size_t num_opt_found = CONTINOUS_CAST->num_optima_found();
			size_t num_opt_known = CONTINOUS_CAST->get_optima().number_objective();
			real peak_ratio = (real)num_opt_found / (real)num_opt_known;
			real success_rate = CONTINOUS_CAST->solved() ? 1 : 0;
			measure::get_measure()->record(global::ms_global.get(), evals, peak_ratio, success_rate);
		}
		else {
			// ******* Global Optimization ************
			size_t evals = CONTINOUS_CAST->evaluations();
			real err = std::fabs(problem::get_sofar_best<solution<>>(0)->objective(0) - CONTINOUS_CAST->get_optima().objective(0).at(0));
			measure::get_measure()->record(global::ms_global.get(), evals, err);
		}
	}
}